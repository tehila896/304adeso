# CustomerData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nationalId** | **String** | National Id |  [optional]
**gender** | [**GenderEnum**](#GenderEnum) | Gender |  [optional]
**firstname** | **String** | Firstname |  [optional]
**lastname** | **String** | Lastname |  [optional]
**address** | [**AddressData**](AddressData.md) |  |  [optional]

<a name="GenderEnum"></a>
## Enum: GenderEnum
Name | Value
---- | -----
UNDEFINED | &quot;UNDEFINED&quot;
MALE | &quot;MALE&quot;
FEMALE | &quot;FEMALE&quot;
PLAYERS_COMMUNITY | &quot;PLAYERS_COMMUNITY&quot;
COMPANY | &quot;COMPANY&quot;
FAMILY | &quot;FAMILY&quot;
