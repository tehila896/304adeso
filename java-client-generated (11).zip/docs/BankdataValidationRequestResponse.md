# BankdataValidationRequestResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nationalId** | **String** | National ID |  [optional]
**processResult** | [**ProcessResultEnum**](#ProcessResultEnum) | Process result |  [optional]
**errorMessage** | **String** | Error message |  [optional]

<a name="ProcessResultEnum"></a>
## Enum: ProcessResultEnum
Name | Value
---- | -----
OK | &quot;OK&quot;
NOT_FOUND | &quot;NOT_FOUND&quot;
ERROR | &quot;ERROR&quot;
