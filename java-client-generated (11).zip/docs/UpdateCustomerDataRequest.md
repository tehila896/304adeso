# UpdateCustomerDataRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerData** | [**CustomerData**](CustomerData.md) |  |  [optional]
**bankaccountData** | [**BankAccountData**](BankAccountData.md) |  |  [optional]
**creditcardData** | [**CreditcardData**](CreditcardData.md) |  |  [optional]
**customerSettings** | [**CustomerSettings**](CustomerSettings.md) |  |  [optional]
