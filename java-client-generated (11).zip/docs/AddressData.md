# AddressData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cityName** | **String** | City name |  [optional]
**cityId** | **String** | City id |  [optional]
**streetName** | **String** | Street name |  [optional]
**streetId** | **String** | Street id |  [optional]
**streetNo** | **String** | Street number |  [optional]
**poBox** | **String** | PO box |  [optional]
**zipcode** | **String** | Zipcode |  [optional]
