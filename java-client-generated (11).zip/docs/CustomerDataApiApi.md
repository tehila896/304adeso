# CustomerDataApiApi

All URIs are relative to *https://lfapi-test.pais.corp*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateCustomerData**](CustomerDataApiApi.md#updateCustomerData) | **PUT** /api/customer | Update data of a customer. Matches BPM204

<a name="updateCustomerData"></a>
# **updateCustomerData**
> UpdateCustomerDataResponse updateCustomerData(body)

Update data of a customer. Matches BPM204

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerDataApiApi;


CustomerDataApiApi apiInstance = new CustomerDataApiApi();
UpdateCustomerDataRequest body = new UpdateCustomerDataRequest(); // UpdateCustomerDataRequest | 
try {
    UpdateCustomerDataResponse result = apiInstance.updateCustomerData(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerDataApiApi#updateCustomerData");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdateCustomerDataRequest**](UpdateCustomerDataRequest.md)|  |

### Return type

[**UpdateCustomerDataResponse**](UpdateCustomerDataResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

