# ErrorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorCode** | **String** | Error errorCode representing a single exception. |  [optional]
**message** | **String** | An internal error message. |  [optional]
**stackTrace** | **String** | Optional additional information about the error that occurred. |  [optional]
**errorData** | [**ErrorData**](ErrorData.md) |  |  [optional]
